package fpl.quangnm.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;


public class MainActivity2 extends AppCompatActivity {
    FirebaseFirestore database;
    TextView tv;
    Button button, button2,button3;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        database = FirebaseFirestore.getInstance(); // khoi tao database
        tv = findViewById(R.id.textView);
        button3 = findViewById(R.id.button3);
        button2 = findViewById(R.id.button2);
        button = findViewById(R.id.button);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertFirebase(tv);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateFirebase(tv);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteFirebase(tv);
            }
        });
        SelectDataFromFireBase(tv);
    }
    String id = "";
    TODO todo = null;

    public void insertFirebase(TextView tv){
        id = UUID.randomUUID().toString(); // lay 1 id bat ky
        todo = new TODO(id,"title 1","content 1"); // tao doi tuong de insert
        HashMap<String, Object> mapTodo = todo.converHashMap();
        // insert vao database
        database.collection("TODO").document(id)
                .set(mapTodo)  // doi tuong can insert
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tv.setText("Them thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tv.setText("Them that bai");
                    }
                });
    }
    public void updateFirebase(TextView tv){
        id="c9ee789d-52b9-4b5d-a96f-7acca3b1e19c";
        todo = new TODO(id,"sua title 1","sua content 1");
        database.collection("TODO").document(todo.getId())
                .update(todo.converHashMap())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tv.setText("Sua thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tv.setText(e.getMessage());
                    }
                });
    }

    public void  deleteFirebase(TextView tv){
        id="c9ee789d-52b9-4b5d-a96f-7acca3b1e19c";
        database.collection("TODO").document(id)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tv.setText("Xoa thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tv.setText(e.getMessage());
                    }
                });
    }
    String strResult = "";
    public ArrayList<TODO> SelectDataFromFireBase(TextView tv){
        ArrayList<TODO> list = new ArrayList<>();
        database.collection("TODO")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            strResult = "";
                            for ( QueryDocumentSnapshot document : task.getResult()) {
                                // chuyen dong doc duoc sang doi tuong
                                TODO todo1 = document.toObject(TODO.class);
                                strResult += "Id: " + todo1.getId() + "\n";
                                list.add(todo1); // them vao list
                            }
                            // hien thi ket qua
                            tv.setText(strResult);
                        } else {
                            tv.setText("Doc du lieu that bai");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tv.setText(e.getMessage());
                    }
                });
        return list;
    }
}